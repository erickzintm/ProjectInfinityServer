---
navigation:
    parent: upgrades/upgrades-index.md
    title: "血魔法升级"
    icon: "bloodmagicwootaddon:blood_collector_upgrade"
    position: 2
---
# 血魔法升级

<ItemImage id="bloodmagicwootaddon:blood_collector_upgrade" scale="3"/>

来自血魔法拓展模组的工厂升级。

## <ItemImage id="bloodmagicwootaddon:blood_collector_upgrade" scale="0.5" /> 生命源质收集升级

在将此升级放入工厂前，你需要先右击<ItemImage id="bloodmagic:altar" scale="0.5"/>血之祭坛以进行绑定。

该升级的运作方式类似于「受难之井」仪式：在工厂每次进行生成时，它会从你的灵魂网络中消耗<WootConfig key="addon.bloodmagic.blood_collector_cost" />生命源质，随后产生对应怪物数量的生命源质，并将其存入绑定的血之祭坛中。

若未绑定任何<ItemImage id="bloodmagic:altar" scale="0.5"/>血之祭坛，该升级将不会生效，亦不会消耗任何生命源质。